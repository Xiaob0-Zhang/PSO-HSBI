% Author: Zhang Xiaobo
% Date: 2024.11.05
function output = HSBI(Y, A, maxiter)
% Initialization
[N_mic, N_point] = size(A);
L = length(Y(1, :));
tol = 1e-3;

a = 0.0001; b = 0.0001; alpha = 0.01; % Noise precision
mu = A' * Y;
% mu = ones(N_point, 1);
kesai = sum(abs(mu), 2) / (N_mic * L);
c = randn(N_point, 1) * 0.0001;
% c = ones(N_point, 1) * 0.0001;
r = ones(N_point, 1);
rho = ones(N_point, 1);
sqrt_L = sqrt(L); rho_hat = rho / L;

converged = false;
iter = 0;

while ~converged
    kesai_last = kesai;
    iter = iter + 1;

    % (1) Calculate sigma and mu
    sigma_t = A * diag(kesai) * A' + 1 / alpha * eye(N_mic);
    sigma = diag(kesai) - diag(kesai) * A' * inv(sigma_t) * A * diag(kesai);
    mu = alpha * sigma * A' * Y;

    % (2) Update kesai
    exp_l2 = sum(abs(mu).^2, 2) + diag(sigma);
    kesai = (sqrt(1 + 4 * rho_hat .* exp_l2) - 1) ./ (2 * rho_hat);

    % (3) Update rho
    rho = 1 ./ (kesai + 1 ./ r);

    % (4) Update gamma
    r = (1 + sqrt(1 - 16 * c .* abs(rho))) ./ (4 * c);

    % (5) Update alpha
    gamma = zeros(N_point, 1);
    for i = 1:N_point
        gamma(i, 1) = 1 / alpha * (1 - sigma(i, i) / kesai(i, 1));
    end
    exp_lF = (norm(Y / sqrt_L - A * mu / sqrt_L, 'fro'))^2 + sum(gamma);
    alpha = (N_mic + (2 * a - 2) / L) / (exp_lF + 2 * b / L); 

    % Check convergence
    erro = norm(kesai_last - kesai) / norm(kesai_last);
    if erro < tol || iter >= maxiter
        converged = true;
    end
end

output.mu = mu;
output.sigma = sigma;
output.iter = iter;
end
