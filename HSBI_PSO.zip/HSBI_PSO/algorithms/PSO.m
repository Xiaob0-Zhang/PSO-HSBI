% Author: Zhang Xiaobo
% Date: 2024.11.05
function [updated_angle, updated_power] = PSO(A, y, initial_angle,  mic_pos, lambda)
    num_fine = length(initial_angle(:,1));
    updated_angle = zeros(num_fine, 2);
    updated_power = zeros(num_fine, 1);

    % Defining the search range
    delta_theta= 5; 
    delta_phi= 5;
    for k = 1:num_fine
        % Particle Swarm Optimization (PSO) parameters
        numParticles = 10;
        numDimensions = 2;
        maxIter = 20;

        lb = [initial_angle(k,1) - delta_theta / 1, initial_angle(k,2) - delta_phi / 1];
        ub = [initial_angle(k,1) + delta_theta / 1, initial_angle(k,2) + delta_phi / 1];
        lb(lb < 0) = 0; 
        ub(ub(:, 1) > 90, 1) = 90; 
        ub(ub(:, 2) > 360, 2) = 360; % Constrain search boundaries

        w_start = 0.9;  % Initial inertia weight
        w_end = 0.4;    % Final inertia weight
        v_max = (ub - lb) * 0.1;  % Maximum velocity limit

        % Initialize particle positions and velocities
        pos = bsxfun(@plus, lb, bsxfun(@times, (ub - lb), rand(numParticles, numDimensions)));
        vel = zeros(numParticles, numDimensions);
        personalBest = pos;
        personalBestValue = arrayfun(@(i) objectiveFunction(pos(i,:), A, y, mic_pos, lambda), 1:numParticles, 'UniformOutput', false);
        
        % Initialize global best
        personalBestValue = cell2mat(personalBestValue);
        [globalBestValue, idx] = min(personalBestValue);
        globalBest = personalBest(idx, :);
    
        % Main loop
        for iter = 1:maxIter
            c1 = 1.5 + rand();
            c2 = 1.5 + rand();
            w = w_start - ((w_start - w_end) * (iter / maxIter));
            for i = 1:numParticles
                % Update velocity
                vel(i,:) = w * vel(i,:) + c1 * rand() * (personalBest(i,:) - pos(i,:)) + c2 * rand() * (globalBest - pos(i,:));
                vel(i,:) = sign(vel(i,:)) .* min(abs(vel(i,:)), v_max);

                % Update position
                pos(i,:) = pos(i,:) + vel(i,:);
                
                % Ensure position is within bounds
                pos(i,:) = max(pos(i,:), lb);
                pos(i,:) = min(pos(i,:), ub);

                % Update personal best
                currentValue = objectiveFunction(pos(i,:), A, y, mic_pos, lambda);
                if currentValue < personalBestValue(i)
                    personalBestValue(i) = currentValue;
                    personalBest(i,:) = pos(i,:);
                end
            end

            % Update global best
            [minValue, idx] = min(personalBestValue);
            if minValue < globalBestValue
                globalBestValue = minValue;
                globalBest = personalBest(idx, :);
            end
        end
        
        updated_angle(k,:) = [globalBest(1), globalBest(2)];
        updated_power(k) = -globalBestValue;
    end
end

function P = objectiveFunction(x, A, y, mic_pos, lambda)
    N_mic = length(A(:,1));
    F = zeros(N_mic, 1);
    L = length(y(1,:));
    theta = x(1) * pi / 180;
    phi = x(2) * pi / 180;

    for i = 1:N_mic
        F(i) = exp(-1j * 2 * pi * (sin(theta) * cos(phi) * mic_pos(i,1) + sin(theta) * sin(phi) * mic_pos(i,2)) / lambda);
    end
    Pn = F' * y;
    P = -(sum(abs(Pn).^2, 2) / L^2);   
end
