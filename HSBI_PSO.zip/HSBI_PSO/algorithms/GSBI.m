% refre:Dai, Jisheng, et al. "Root sparse Bayesian learning for off-grid DOA estimation." IEEE Signal Processing Letters 24.1 (2016): 46-50.
function output = GSBI(Y, A, L, maxiter)
% Initialization
[N_mic, N_point] = size(A);
a = 0.0001; b = 0.0001; d = 0.01;
tol = 1e-3;

beta = 1;
mu = A' * Y;
% mu = ones(N_point, 1);
kesai = sum(abs(mu), 2) / (N_mic * L);
converged = false;
iter = 0;

while ~converged
   iter = iter + 1;
   delta_last = kesai; % Update delta
   
   % Update Sigma
   Phi = A;   % Reassign the steering vector to a variable for matrix operations
   V_temp = 1 / beta * eye(N_mic) + Phi * diag(kesai) * Phi';
   Vinv = inv(V_temp); % Simplify matrix inversion for computation

   sigma = diag(kesai) - diag(kesai) * Phi' * Vinv * Phi * diag(kesai);
   mu = beta * sigma * Phi' * Y;
   gamma1 = 1 - real(diag(sigma)) ./ kesai;
   
   % Update delta
   temp = sum(mu .* conj(mu), 2) + L * real(diag(sigma)); % sum(,2) sums along rows
   kesai = (-L + sqrt(L^2 + 4 * d * real(temp))) / (2 * d);
   
   % Update beta
   resid = Y - Phi * mu;
   beta = (L * N_mic + (a - 1)) / (b + norm(resid, 'fro')^2 + L / beta * sum(gamma1));
   
   % Check convergence
   erro = norm(kesai - delta_last) / norm(delta_last);
   if erro < tol || iter >= maxiter
       converged = true;
   end
end

output.mu = mu;
output.sigma = sigma;
output.iter = iter;
end
