% This code implements the HSBI-PSO multi-source localization for simulated sound sources
% Author: Zhang Xiaobo
% Date: 2024.11.5

clear;
clc;
close all;
addpath function\
addpath algorithms\

%% Construct signal
% Scanning range theta: -90 -> 90, phi: 0 -> 360
resol_theta = 5;
resol_phi = 5;
theta_scan = 0:resol_theta:90;
phi_scan = 0:resol_phi:360;
[theta_all, phi_all] = meshgrid(theta_scan, phi_scan);
search_area = [theta_all(:), phi_all(:)];
N_point = length(search_area(:,1));

% Load microphone position information
load 56_spiral_array.mat
mic_x_axis = array(:,1); 
mic_y_axis = array(:,2); 
mic_z_axis = zeros(length(mic_x_axis),1);
mic_pos = [mic_x_axis mic_y_axis mic_z_axis];
mic_centre = mean(mic_pos);

% Source parameters
N_source = 2; % Number of sound sources
c = 343; 
SNR = 10; 
% Note: If the frequency you need deviates significantly from the current frequency, please adjust the array size,
% the threshold in the PSO_Pre_Process function, or the search range of your PSO!
f = 20e3; 
L = 100;
SPL = ones(N_source,1) * 100;
lamda = c / f;

% Simulate sound intensity data
res = Simulate_signal(N_source, mic_pos, c, f, SNR, SPL, L); 
Y = res.y;
true_source_pos = res.source_pos;

%% HSBI
% Number of iterations
maxiter = 80;  %(50~100 is good)

% Define steering matrix
res_steer = steer_Amn(search_area, mic_pos, c, f);
A = res_steer.A;  

tic
output = HSBI(Y, A, maxiter);
mu = output.mu;  
sigma = output.sigma;
t_HSBI = toc;

% Calculate results
power_ = sum(abs(mu).^2,2) / L;
power = power_ ./ max(power_);
fprintf("HSBI phase completed, time elapsed (seconds): %.2f\n", t_HSBI);

%% PSO
tic
fine_index = PSO_Pre_Process(power);

% Define initial scanning range
initial_angle = search_area(fine_index,:); 
[updated_angle, updated_power_] = PSO(A, Y, initial_angle,  mic_pos, lamda);
t_PSO = toc;
fprintf("PSO phase completed, time elapsed (seconds): %.2f\n", t_PSO);

updated_power = updated_power_ ./ max(updated_power_);
power(fine_index) = updated_power;
search_area(fine_index,:) = updated_angle;
theta = search_area(:,1); 
phi = search_area(:,2);

plot_res1(power, theta, phi, true_source_pos, 'HSBI-PSO');
% plot_res2(power, theta_scan, phi_scan, 1);