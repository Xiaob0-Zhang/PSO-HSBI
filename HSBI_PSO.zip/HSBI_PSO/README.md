# PSO-HSBI
# A Novel Two-Stage DOA Estimation of Sound Sources Based on Hierarchical Sparse Bayesian Inference

This project includes two examples, example1 and example2. 
Example1 demonstrates the principles of the PSO-HSBI algorithm,
while example2 compares the sparsity and noise resistance performance of the traditional GSBI and HSBI methods.