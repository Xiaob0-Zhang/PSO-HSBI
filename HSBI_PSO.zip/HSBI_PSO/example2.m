% Author: Zhang Xiaobo
% Date: 2024.11.5

clear;
clc;
close all;
addpath function\
addpath algorithms\
addpath Signal_Generator\

[array_signal, fs] = audioread("generated_signal.wav");
array_signal = array_signal';

%% Construct signal
% Scanning range theta: -90 -> 90, phi: 0 -> 360
resol_theta = 5;
resol_phi = 5;
theta_scan = 0:resol_theta:90; 
phi_scan = 0:resol_phi:360;
[theta_all, phi_all] = meshgrid(theta_scan, phi_scan);
search_area = [theta_all(:), phi_all(:)];
N_point = length(search_area(:,1));

% Load microphone position information
load 56_spiral_array.mat
mic_x_axis = array(:,1) + 3; % Coordinates need to be adjusted based on generated_signal
mic_y_axis = array(:,2) + 3; 
mic_z_axis = zeros(length(mic_x_axis), 1);
mic_pos = [mic_x_axis mic_y_axis mic_z_axis];
mic_centre = mean(mic_pos);

% Source parameters
c = 343; 
SNR = -15; 
f = 12e3; % Frequency needs to be adjusted based on generated_signal
L = 100; % Length
lamda = c / f;

% Audio clipping
start_sample = 1e4;
bandwidth = 1e3;
order = 4;

% Add noise
noisy_signal = zeros(size(array_signal)); % Initialize noisy signal matrix
for i = 1:size(array_signal, 1)
    noisy_signal(i, :) = awgn(array_signal(i, :), SNR, 'measured'); % Add noise to each channel
end

% Filtering
% filtered_signal = bandpass_filter(noisy_signal, fs, f, bandwidth, order);
% Y = filtered_signal(:, start_sample:L+start_sample-1);

Y = noisy_signal(:, start_sample:L+start_sample-1);

% Fourier Transform
% Y = fft(Y, L, 2);
% Y = Y(:, 1:round(L/2)-1);

%% Bayesian
mode_algorithm = 2; % 1.GSBI, 2.HSBI
maxiter = 80;

% Define steering matrix
res_steer = steer_Amn(search_area, mic_pos, c, f);
A = res_steer.A; 

tic
% ~~~~~~~~~~~~~~~GSBI~~~~~~~~~~~~~~~~~~
if mode_algorithm == 1
    output = GSBI(Y, A, L, maxiter);
    mu = output.mu; 
    sigma = output.sigma;
end

% ~~~~~~~~~~~~~~~HSBI~~~~~~~~~~~~~~~~~~
if mode_algorithm == 2
    output = HSBI(Y, A, maxiter);
    mu = output.mu; 
    sigma = output.sigma; 
end
time = toc;
fprintf("Time elapsed (seconds): %f\n", time);

%% Calculate results
power_ = sum(abs(mu).^2, 2) / L;
power = power_ ./ max(power_);

plot_res2(power, theta_scan, phi_scan, mode_algorithm);
