function plot_res2(power, theta_scan, phi_scan, mode)
    % Set the title based on the mode
    if mode == 1 
        title_name = "GSBI";
    elseif mode == 2
        title_name = "HSBI";
    end
    
    % Reshape the power vector to match the theta and phi grid size, ensuring correct row and column order
    P_result = reshape(power, length(phi_scan), length(theta_scan));
    
    % Create the grid for theta and phi
    [Theta, Phi] = meshgrid(theta_scan, phi_scan);
    
    % Plot the contour map
    axes1 = axes('Parent', figure);
    contourf(Theta, Phi, P_result, 'LineColor', 'none');
    colorbar;
    
    ylabel('phi (degrees)', 'FontWeight', 'bold', 'FontName', 'Arial');
    xlabel('theta (degrees)', 'FontWeight', 'bold', 'FontName', 'Arial');
    
    title(title_name, 'FontWeight', 'bold', 'FontName', 'Arial');
    
    set(axes1, 'LineWidth', 1, 'BoxStyle', 'full', 'FontName', 'Arial', 'FontSize', 15, 'FontWeight', 'bold', 'Layer', 'top');
    box on;

end
