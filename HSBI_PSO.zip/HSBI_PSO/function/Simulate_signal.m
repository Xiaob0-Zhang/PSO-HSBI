function result = Simulate_signal(N_source, mic_pos, c, f, SNR, SPL, L)

    N_mic = length(mic_pos(:,1));
    
    % Generate random angles
    random_temp_theta = 90 * rand(1, N_source);
    random_temp_phi = 360 * rand(1, N_source);
    
    % Round to two decimal places
    source_theta = round(random_temp_theta, 2);
    source_phi = round(random_temp_phi, 2);

%     Use fixed test sound sources
%     source_theta = [32.18;  38.18; 58.14; 67.23]';
%     source_phi = [88.85; 88.85; 124.77; 234.77]';
%     source_theta = [32.18;  38.18]';
%     source_phi = [88.85; 198.85]';

    source_pos = [source_theta', source_phi', SPL];
    g_ms = steer_Amn(source_pos(:,1:2), mic_pos, c, f);

    amp = zeros(N_source, 1);
    q_s = zeros(N_source, L);
    P_true = zeros(N_source, 1);
    
    for i = 1:N_source
        amp(i, 1) = 2e-5 * 10^(SPL(i, 1) / 20);
        q_s(i, :) = sqrt(amp(i, 1) / 2) * (randn(1, L) + 1i * randn(1, L));
        P_true(i, 1) = sum(abs(q_s(i, :)).^2, 2) / L;  % Signal energy (equivalent to amp)
    end
    
    P_noise = mean(P_true) / (10^(SNR/10));
    P_noise = mean(P_noise);  % Average noise level, assuming uniform sound pressure across signals
    N = sqrt(P_noise / 2) * (randn(N_mic, L) + 1i * randn(N_mic, L));
    y = g_ms.A * q_s + N;

    result.y = y;
    result.source_pos = source_pos;

end
