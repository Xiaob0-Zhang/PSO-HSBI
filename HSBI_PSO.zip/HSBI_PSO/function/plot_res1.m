function plot_res1(power, theta, phi, res_true, mode_algorithm)

% Find predicted sources
index_maxk = find(power > 0.5);
res_pre(:,1) = theta(index_maxk); 
res_pre(:,2) = phi(index_maxk);
power_pre = power(index_maxk);
res_pre(:,3) = (20 * log10((power_pre * 2) / 2e-5)); % Convert to dB

% Distance plot
axes1 = axes('Parent', figure);
sc1 = scatter(res_true(:,1), res_true(:,2), [], res_true(:,3), 'Marker', 'o', 'LineWidth', 1.5);
sc1.SizeData = 200; % Set marker size
sc1.MarkerFaceColor = 'none'; % Set marker fill color
sc1.MarkerEdgeColor = 'flat'; % Set marker edge color
sc.MarkerEdgeWidth = 2; % Set marker border line width (thicker border)
hold on
sc2 = scatter(res_pre(:,1), res_pre(:,2), [], res_pre(:,3), 'Marker', '*', 'LineWidth', 1.5);
sc2.SizeData = 200; % Set marker size
sc2.MarkerFaceColor = 'none'; % Set marker fill color
sc2.MarkerEdgeColor = 'flat'; % Set marker edge color
sc.MarkerEdgeWidth = 6; % Set marker border line width (thicker border)
xlim([0, 90]);
ylim([0, 360]);
xticks(0:15:90);
yticks(0:45:360);
colormap('jet');
legend([sc1, sc2], {'Actual source', 'Predicted source'}, 'Location', 'best', 'Box', 'off'); % Display legend in best location
grid on

% Set colorbar range and tick positions
clim([max(res_pre(:,3)) - 20, max(res_pre(:,3))]);  
ticks_pos = linspace(max(res_pre(:,3)) - 20, max(res_pre(:,3)), 3);  % Set tick positions

% Create colorbar and set tick positions and labels
cb = colorbar;
cb.Ticks = ticks_pos;
cb.TickLabels = {'-20', '-10', '0'};

ylabel('phi (degrees)', 'FontWeight', 'bold', 'FontName', 'Arial');
xlabel('theta (degrees)', 'FontWeight', 'bold', 'FontName', 'Arial');

title(mode_algorithm, 'FontWeight', 'bold', 'FontName', 'Arial');

set(axes1, 'LineWidth', 1, 'BoxStyle', 'full', 'FontName', 'Arial', 'FontSize', 15, 'FontWeight', 'bold', 'Layer', 'top');
box on;

end
