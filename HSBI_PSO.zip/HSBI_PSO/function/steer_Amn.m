function res_steer=steer_Amn(search_area, mic_pos, c, f)
    theta= search_area(:,1)*pi/180;
    phi= search_area(:,2)*pi/180;
    lamda=c/f;
    N_mic=length(mic_pos(:,1));
    N_point=length(search_area(:,1));

    A=zeros(N_mic,N_point);
    for i=1:N_mic
        for j=1:N_point
            
            A(i,j)= exp(-1j*2*pi*(sin(theta(j))*cos(phi(j))*mic_pos(i,1)+sin(theta(j))*sin(phi(j))*mic_pos(i,2))/lamda);
        end
    end
    res_steer.A=A;
end