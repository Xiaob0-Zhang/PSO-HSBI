function filtered_data = bandpass_filter(array_data, fs, center_freq, bandwidth, order)
    % bandpass_filter applies a bandpass filter to microphone signals
    %
    % Input parameters:
    % array_data   - 56xN matrix, where each row represents a microphone signal
    % fs           - Sampling rate (Hz)
    % center_freq  - Center frequency of the bandpass filter (Hz)
    % bandwidth    - Bandwidth of the bandpass filter (Hz)
    % order        - Filter order
    %
    % Output parameters:
    % filtered_data - Microphone signal data after filtering

    % Calculate the cutoff frequencies for the bandpass filter
    lowcut = center_freq - bandwidth / 2;
    highcut = center_freq + bandwidth / 2;

    % Design the bandpass filter
    [b, a] = butter(order, [lowcut, highcut] / (fs / 2), 'bandpass');

    % Initialize the filtered data
    filtered_data = zeros(size(array_data));

    % Apply the filter to each microphone signal
    for i = 1:size(array_data, 1)
        filtered_data(i, :) = filter(b, a, array_data(i, :));
    end
end
