% Set a threshold to find the indices of the grid that need refinement.
% For a simple scenario, the threshold can be set lower.
function fine_index = PSO_Pre_Process(power)
    [peaks, locs] = findpeaks(power);
    peaks_index = peaks > 0.3; 
    fine_index = locs(peaks_index);
end
